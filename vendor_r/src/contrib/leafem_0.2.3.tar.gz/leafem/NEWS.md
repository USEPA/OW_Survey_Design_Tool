# leafem 0.2.3 (2023-09-17)

# leafem 0.2.2 (2023-09-16)

#### ✨ features and improvements

  * new suite of functions to add PMTiles served from S3 bucket.
  * `addFgb()` now responds to click, mouseover & mouseout in shiny (thanks to @dfriend21). #64

#### ✨ features and improvements

  * `addFGB()` now accepts arbitrary labels. #53
  * update georaster-layer-for-leaflet version to 3.7.1

#### 🐛 bug fixes

  * update flatgeobuf geojson js lib to latest version. (https://github.com/r-spatial/mapview/issues/411)
  * fix parsing of negative coordinates in `clip2sfc()`. @famuvie #45
  * remove offending character conversion in `addStaticLabels()`. @jannes-m #47
  * address changes in latest `stars` version which caused CRAN ERRORs. #70

#### 🍬 miscellaneous

  * removed `gdalUtils` dependency using new `sf::st_layers()` instead.
  * remove `rgdal` from Suggests.

## leafem 0.1.8

bugfixes:

  * (unexported) addCOG now works much better after updating JS deps. #48
  * georaster.noDataValue now mapped correctly to na.color. #52

## leafem 0.1.6

new features:

  * new function addReactiveFeatures to show/hide one layer when clicking on another. #38

bugfixes:

  * imageQuery now properly updated in shiny. #27
  * homeButton did not work for extents with xmin = 0. #40

miscellaneous:

  * add(Raster/Stars)RGB default quantile stretching now between 0 & 1.

## leafem 0.1.3

new features:

  * addFgb has gained argument className to allow css specification.
  * new functions addGeotiff and addGeoRaster to render large raster data using https://github.com/GeoTIFF/georaster-layer-for-leaflet

bugfixes:

  * don't use st_zm for addFeatures.mapdeck
  * remove mousecoords strip only if it exists. #23
  * addFgb now respects pane passed via options.
  * addFgb used to fail LayerId contained . (dot).
  * addFgb uses layerId instead of group to attach to html.

## leafem 0.1.0

new features:

  * addHomeButton now infers bounding box from group argument without having to pass extent object. Also it now handles vectors of c(xmin, ymin, xmax, ymax) - e.g. via sf::st_bbox(). This is a backward-breaking change!
  * addLocalFile has gained argument `tms` to specify whether tiles are TMS tiles.
  * new function `updateLayersControl` to update (or add) layers control when adding new base or overlay layers to an existing map (https://twitter.com/mdsumner/status/1194596180061118465).
  * added support for 'mapdeck' maps in addFeatures.
  * added methods addStarsImage (moved from mapview) and addRasterRGB. Thanks to Luigi Ranghetti #1.
  * addFeatures now also works with leaflet_proxy objects. Thanks Lorento Busetto #2.
  * new function `addFgb` to add flatgeobuf files from file or url.
  * addImageQuery now much more robust. Also works with leaflet_proxy objects now. Thanks to Sebastian Gatscha #9, #12, #13

miscellaneous:

  * garnishMap now uses match.arg and tries to be more robust.

## leafem 0.0.1

initial commit
